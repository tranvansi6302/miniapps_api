/**
 * 365EJSC Mini App Framework Core
 * Đây là file core của bạn. Hãy thay nội dung này bằng bản build thực tế.
 */
console.log('365EJSC Framework Loaded from Local');
